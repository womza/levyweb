<?php
printf('<div class="slz-accordion timeline-container slz-shortcode edu-feature %s edu-feature-%s"><div id="accordion-%s" role="tablist" class="timeline panel-group list-unstyled edu-feature-list accordion">%s</div></div>', esc_attr($extra_class), esc_attr($id), esc_attr($id), $content );
