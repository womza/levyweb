== Slzexploore_Core ==
Contributors: swlabs
Tags: custom post type, shortcode, metabox.

Slzexploore_Core plugin compatible with Exploore Wordpress template.

Thanks for your support and feel free to contact us any time. 
Our support forum is here:

http://support.swlabs.co/

== Changelog ==
= 2.0 - 28/06/2016 =
