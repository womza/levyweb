jQuery(document).ready(function($) {
	"use strict";
	$('.slzexploore_core-meta-color').wpColorPicker();
});